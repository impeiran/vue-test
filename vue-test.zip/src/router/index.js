import Vue from 'vue'
import Router from 'vue-router'
import shakeDemo from '@/components/shakeDemo'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'shakeDemo',
      component: shakeDemo
    }
  ]
})
