const DEFAULT_THRESHOLD = 200
const DEFAULT_TIME_LIMIT = 800

class Shake {
  constructor (threshold, timeLimit) {
    if (!window.DeviceMotionEvent) {
      return null
    } else {
      this._init(threshold, timeLimit)
      return this
    }
  }
  // 启动摇一摇
  go (callback) {
    this.callback = callback
    this.handler = this._eventHandler()
    window.addEventListener('devicemotion', this.handler, false)
  }
  // 初始化参数
  _init (threshold, timeLimit) {
    this.threshold = threshold || DEFAULT_THRESHOLD
    this.timeLimit = timeLimit || DEFAULT_TIME_LIMIT
    this.handler = null
  }
  // 闭包 存放事件相关信息 && 事件回调
  _eventHandler () {
    let _this = this

    // 时间差进行函数节流
    let currentTime = 0
    let lastTime = 0

    let currentX = 0
    let currentY = 0
    let currentZ = 0

    let lastX = 0
    let lastY = 0
    let lastZ = 0

    // 摇一摇关键
    return function (e) {
      currentTime = +new Date()
      if (currentTime - lastTime > _this.timeLimit) {
        let acc = e.accelerationIncludingGravity
        lastTime = currentTime
        currentX = parseFloat(acc.x.toFixed(4))
        currentY = parseFloat(acc.y.toFixed(4))
        currentZ = parseFloat(acc.z.toFixed(4))
        let differ = Math.abs(currentX + currentY + currentZ - lastX - lastY - lastZ) * 10

        if (differ > _this.threshold) {
          if (typeof _this.callback === 'function') {
            _this.callback()
          }
          _this._removeEvent()
        }

        lastX = currentX
        lastY = currentY
        lastZ = currentZ
      }
    }
  }
  // 移除事件并清除闭包
  _removeEvent () {
    window.removeEventListener('devicemotion', this.handler, false)
    this.handler = null
  }
}

export default Shake
