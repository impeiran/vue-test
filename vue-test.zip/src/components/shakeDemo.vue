<script>
import Shake from '@/utils/Shake'
export default {
  data () {
    return {
      nums: 0,
      shake: undefined
    }
  },
  methods: {
    goshake () {
      this.shake.go(() => {
        this.nums++
      })
    }
  },
  mounted () {
    this.shake = new Shake()
    console.log(this.shake)
  }
}
</script>

<template>
  <div>
    <div>hello world</div>
    <div>{{nums}}</div>
    <button @click="goshake">Go</button>
  </div>
</template>

<style lang="scss" scoped>
  button{
    width: 40px;
    color: #fff;
    background: #128fdc;
  }
</style>
